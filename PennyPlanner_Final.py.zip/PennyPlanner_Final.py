from graphics import *
import matplotlib.pyplot as plt

#creation of PennyPlanner class
class PennyPlanner:
    def __init__(self):
        #Start by creating the app with the main window and default values for budget, categories, and expense history.
        self.win = GraphWin("Penny Planner", 650, 750)
        # to store budget information:
        self.total_budget = 0
        # store expense categories:
        self.categories = {}
        # list to store tuples of expense history (expense category and amount):
        self.expense_history = [] #This way we create the function for further need.

    def main_menu(self):
        #Creation of the main menu screen with a welcome text and navigation buttons.
        welcome_text = Text(Point(325, 250), 'Welcome to PennyPlanner, \n the app that will help you track your expenses\nand achieve your savings goals!')
        welcome_text.setSize(22) #Sets the size of the text.
        welcome_text.setTextColor("#0B3484")
        welcome_text.draw(self.win) #We add to the app what has been defined before

        #Display the app logo, designing the lengths and colours that we want.
        circle = Circle(Point(325, 425), 50)
        circle.setFill("#0B3484")
        circle.draw(self.win)
        pp_text = Text(Point(325, 425), "PP")
        pp_text.setSize(18)
        pp_text.setTextColor("tomato")
        pp_text.draw(self.win)

        #The creation of an exit button (exist the app) and the continue button.
        exit_button = self.create_button(Point(100, 600), "Exit", self.win, "#0B3484", "white")
        continue_button = self.create_button(Point(550, 600), "Continue", self.win, "tomato", "black")

        while True: #Implemention of a loop to wait for the user interaction (mouse clicks, either continue or exit)
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()

            elif self.is_button_clicked(click_point, continue_button):
                self.determine_total_budget()

# login page --> first page the user will see
    def login_page(self):
        #Create and display the login page with the lengths and characteristics that we are going to define next.

        login_window = GraphWin("Login Page", 650, 750)
        login_window.setBackground("#0B3484")
        #Ask the user for its username
        username_text = Text(Point(325, 250), 'Enter Username:')
        username_text.setSize(22)
        username_text.setTextColor("tomato")
        username_text.draw(login_window)

        username_entry = Entry(Point(325, 300), 20)
        username_entry.draw(login_window)
        #Ask the user to create a password
        pw_text = Text(Point(325, 400), 'Enter Password:')
        pw_text.setSize(22)
        pw_text.setTextColor("tomato")
        pw_text.draw(login_window)

        pw_entry = Entry(Point(325, 450), 20)
        pw_entry.draw(login_window)

        login_button = self.create_button(Point(325, 550), "Login", login_window, "tomato", "#0B3484")

        while True: #Wait for the user to interact depedneding of the mouse click do different options.
            click_point = login_window.getMouse()
            if self.is_button_clicked(click_point, login_button):
                self.username = username_entry.getText()
                break

        login_window.close()
        self.main_menu()

    def determine_total_budget(self):
        #Ask the user to set their total budget for expense tracking, and determining the different properties of that window.
        self.win.close()
        self.win = GraphWin("Determine Total Budget", 650, 750)

        # create entry point for user to input total monthly budget
        entry_text = Text(Point(325, 100), "Enter Total Budget:")
        entry_text.setTextColor("black")
        entry_text.draw(self.win)

        entry = Entry(Point(325, 200), 20)
        entry.draw(self.win)

        exit_button = self.create_button(Point(100, 600), "Exit", self.win, "#0B3484", "white")
        add_categories_button = self.create_button(Point(550, 600), "Add Categories", self.win, "tomato", "black")

        #The creation of a loop that will depend on the user interactionCheck for clicks on 'Exit' or 'Add Categories' buttons. If 'Exit' is clicked, close the window.
        # If 'Add Categories' is clicked we will retrieve and validate the entered budget (must be numeric).
        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()

            elif self.is_button_clicked(click_point, add_categories_button):
                total_budget_str = entry.getText()
                if total_budget_str.isdigit():
                    self.total_budget = int(total_budget_str)
                    self.add_categories()
                    break
                else:
                    entry_text.setText("Invalid input. Enter Total Budget (numeric):") # In case the user inputs an invalid numeric input

    def add_categories(self):
        #Allows the user to add budget categories to organize their different expenses
        self.win.close()
        self.win = GraphWin("Add Categories", 650, 750)
        category_text = Text(Point(325, 100), "Enter Category:")
        category_text.setTextColor("black")
        category_text.draw(self.win)
        #After having written the new category, the determination of its corresponding budget is necessary.
        budget_text = Text(Point(325, 200), "Enter Budget:")
        budget_text.setTextColor("black")
        budget_text.draw(self.win)

        category_entry = Entry(Point(325, 155), 10)
        category_entry.draw(self.win)

        budget_entry = Entry(Point(325, 250), 10)
        budget_entry.draw(self.win)
        #If 'Exit' is clicked, close the window.
        #If 'Add Category' is clicked, we will validate the entered category name and budget.
        exit_button = self.create_button(Point(100, 600), "Exit", self.win, "#0B3484", "white")
        add_category_button = self.create_button(Point(330, 600), "Add Category", self.win, "tomato", "black")
        done_button = self.create_button(Point(550, 600), "Done", self.win, "tomato", "black")

        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()#If the exit button is clicked, the window will close.

            elif self.is_button_clicked(click_point, add_category_button):
                category = category_entry.getText() #If the add category button is clicked, a new category will be created.
                budget = budget_entry.getText()

                if category and budget.isdigit():
                    self.categories[category] = int(budget)
                    category_entry.setText("")
                    budget_entry.setText("")
                else:
                    category_text.setText("Invalid input. Enter Category:")
                    budget_text.setText("Enter Budget:")

            elif self.is_button_clicked(click_point, done_button):
                self.show_budget_summary()
                break

    def track_expenses(self):
        #This function, displays a prompt in order for the user to select an expense category.
        self.win.close()
        self.win = GraphWin("Track Expenses", 650, 750)

        category_text = Text(Point(325, 100), "Select the expense category:")
        category_text.setTextColor("black")
        category_text.setSize(18)
        category_text.draw(self.win)

        #Create and position buttons for each budget category previously defined.
        category_buttons = []
        y_position = 150
        for category in self.categories:
            category_button = self.create_button(Point(325, y_position), f"Track {category}", self.win, "tomato",
                                                 "black")
            category_buttons.append((category, category_button))
            y_position += 50

        back_button = self.create_button(Point(325, 600), "Back", self.win, "tomato", "black")
        #Create a user interface where the user can go back to see the budget summary.
        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, back_button):
                self.show_budget_summary()

            for category, button in category_buttons:
                if self.is_button_clicked(click_point, button):
                    self.track_expense_for_category(category)
                    break

    #We are going to track expenses for a specific category.
    def track_expense_for_category(self, category):
        self.win.close()
        self.win = GraphWin("Track Expenses", 650, 750)
        #Displays the selected category
        category_text = Text(Point(325, 100), f"Category: {category}")
        category_text.setTextColor("black")
        category_text.setSize(18)
        category_text.draw(self.win)
        #Set the different properties of the button and prompt.
        expense_text = Text(Point(325, 200), "Enter the expense amount:")
        expense_text.setTextColor("black")
        expense_text.setSize(18)
        expense_text.draw(self.win)

        expense_entry = Entry(Point(325, 250), 20)
        expense_entry.draw(self.win)

        back_button = self.create_button(Point(325, 600), "Back", self.win, "tomato", "black")
        trackexp_button = self.create_button(Point(325, 300), f"Track Expense for {category}", self.win, "tomato",
                                             "black")

        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, trackexp_button):#Check if the 'Track Expense' button is clicked.
        #Validate the entered expense amount if valid, check if the amount exceeds the budget for the category.
                amount_str = expense_entry.getText()
                if amount_str.isdigit():
                    amount = int(amount_str)
                    if amount > self.categories[category]:#If it exceeds, display an error message.
                        expense_text.setText(f'Error: Expense exceeds available budget for "{category}"')
                    else:
                        self.categories[category] -= amount
                        self.expense_history.append((category, amount))

                        expense_text.setText(f'Expense of ${amount:.2f} in category "{category}" recorded.') #If the input is valid and stays within the budget.
                        self.track_expenses()

                        if self.categories[category] < 0:
                            expense_text.setText(f'Warning: You have exceeded your budget for "{category}"!') #When exceeding the budget of the month displaying a warning
                else:
                    expense_text.setText("Invalid input. Enter a numeric value.")

            elif self.is_button_clicked(click_point, back_button):
                self.track_expenses()


    def show_budget_summary(self):
        #summarize the budget and display it using a pie chart to show the allocation of funds.
        self.win.close()
        self.win = GraphWin("Budget Summary", 650, 750)

        savings = self.total_budget - sum(self.categories.values())#Calculate savings as the total budget minus the sum of category values.
        labels = list(self.categories.keys()) + ["Savings"]
        values = list(self.categories.values()) + [savings]

        colors = ['blue', 'orange', 'green', 'red', 'purple', 'brown', 'pink', 'gray', 'olive', 'cyan']

        plt.pie(values, labels=labels, autopct='%1.1f%%', colors=colors, startangle=140)
        plt.title("Budget Allocation")
        plt.axis('equal')
        plt.show()

        exit_button = self.create_button(Point(100, 600), "Exit", self.win, "#0B3484", "white")
        add_categories_button = self.create_button(Point(330, 600), "Add Categories", self.win, "tomato", "black")
        track_expenses_button = self.create_button(Point(550, 600), "Track Expenses", self.win, "tomato", "black")
        view_history_button = self.create_button(Point(330, 500), "View Expense History", self.win, "tomato", "black")
        budget_button = self.create_button(Point(550, 500), "View Budget", self.win, "tomato", "black")


        while True:#Implement a loop to handle clicks on these buttons and perform corresponding actions.
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()
            elif self.is_button_clicked(click_point, add_categories_button):
                self.add_categories()
                break
            elif self.is_button_clicked(click_point, track_expenses_button):
                self.track_expenses()
                break
            elif self.is_button_clicked(click_point, view_history_button):
                self.display_expense_history()
                break
            elif self.is_button_clicked(click_point, budget_button):
                self.display_budget()
                break

    def display_expense_history(self):
        #Show a history of the different expenses that have been made in a list format.
        self.win.close()
        self.win = GraphWin("Expense History", 650, 750)#New window called "Expense History".

        sorted_expenses = self.quicksort(self.expense_history)
        #Set the different properties
        history_text = Text(Point(325, 50), "Expense History:")
        history_text.setTextColor("black")
        history_text.setSize(18)
        history_text.draw(self.win)

        y_position = 100
        for category, amount in sorted_expenses:
            category_info = f"{category}: ${amount:.2f}"
            Text(Point(325, y_position), category_info).draw(self.win)
            y_position += 30

        exit_button = self.create_button(Point(125, 600), "Exit", self.win, "tomato", "black")
        back_button = self.create_button(Point(325, 600), "Back", self.win, "tomato", "black")
        #Implemention of a loop to handle clicks on these buttons and perform corresponding actions
        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()
            elif self.is_button_clicked(click_point, back_button):
                self.show_budget_summary()  # Replace with the actual method name

    def display_budget(self):
        #Display the status of the budget, including each category and the remaining budget in each of the categories established at the begining.
        self.win = GraphWin("Current Budget", 650, 750)

        budget_text = Text(Point(325, 50), "Current Budget:")
        budget_text.setTextColor("black")
        budget_text.setSize(18)
        budget_text.draw(self.win)


        y_position = 100
        for category, remaining_budget in self.categories.items():
            category_info = f"{category}: ${remaining_budget:.2f} remaining"
            Text(Point(325, y_position), category_info).draw(self.win)
            y_position += 30

        back_button = self.create_button(Point(325, 600), "Back", self.win, "tomato", "black")
        exit_button = self.create_button(Point(125, 600), "Exit", self.win, "tomato", "black")
        #Implement a loop to handle clicks on these buttons and perform corresponding actions.
        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, exit_button):
                self.win.close()
            elif self.is_button_clicked(click_point, back_button):
                self.show_budget_summary()  # Replace with the actual method name

    def create_button(self, center, label, window, button_color, label_color):
        button_width = 130
        button_height = 50

        button = Rectangle(
            Point(center.getX() - button_width / 2, center.getY() - button_height / 2),
            Point(center.getX() + button_width / 2, center.getY() + button_height / 2)
        )
        button.setFill(button_color)
        button.draw(window)

        text = Text(center, label)
        text.setTextColor(label_color)
        text.draw(window)

        return button

    def is_button_clicked(self, click_point, button):
        #We create the helper function to check if a button has been clicked by comparing the click point with the button's coordinates defined above.
        return (
            button.getP1().getX() < click_point.getX() < button.getP2().getX()
            and button.getP1().getY() < click_point.getY() < button.getP2().getY()
        )

    def get_numeric_input(self, prompt, x, y):
        #With the next function we are going to prompt the user for numeric input and validate it.
        text = Text(Point(x, y), prompt)
        text.setTextColor("black")
        text.draw(self.win)

        entry = Entry(Point(x, y + 50), 10)
        entry.draw(self.win)

        ok_button = self.create_button(Point(x - 80, y + 100), "Add Expense", self.win, "tomato", "black")
        cancel_button = self.create_button(Point(x + 80, y + 100), "Cancel", self.win, "tomato", "black")
        #Implement a loop to handle the clicks that have been made and validate input.
        while True:
            click_point = self.win.getMouse()
            if self.is_button_clicked(click_point, ok_button):
                input_text = entry.getText()
                if input_text.isdigit():
                    text.undraw()
                    entry.undraw()
                    ok_button.undraw()
                    cancel_button.undraw()
                    return input_text
                else:
                    text.setText("Invalid input. Enter a numeric value.")
            elif self.is_button_clicked(click_point, cancel_button):
                text.undraw()
                entry.undraw()
                ok_button.undraw()
                cancel_button.undraw()
                return None#Return the corresponding numeric input or None if canceled

    def quicksort(self, lst):
        #Sort a list of items using the quicksort algorithm, which is efficient for large datasets.
        if len(lst) <= 1:
            return lst
        else: #If the list is one item or empty, return it. Otherwise, pick a pivot and partition the list into smaller and greater sublists based on the pivot.
            pivot = lst[0]
            smaller = [x for x in lst[1:] if x[1] <= pivot[1]]
            greater = [x for x in lst[1:] if x[1] > pivot[1]]
            return self.quicksort(greater) + [pivot] + self.quicksort(smaller)

#Different entry points for the application.
if __name__ == "__main__":
    planner = PennyPlanner()
    planner.login_page()

